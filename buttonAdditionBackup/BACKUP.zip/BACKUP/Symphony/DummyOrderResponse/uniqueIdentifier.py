import random

def UniqueIdentifier():
    return random.randint(10000,200000)