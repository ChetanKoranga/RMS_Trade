import React from 'react';
import Cumulative from './cumulative';

const App = () => {
    return <div>
        <div>
            <Cumulative />
        </div>
    </div>
}

export default App;